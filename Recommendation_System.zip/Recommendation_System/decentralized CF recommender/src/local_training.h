class Node {
   public:
    Node(int id);
    Matrix read_local_data();
};
